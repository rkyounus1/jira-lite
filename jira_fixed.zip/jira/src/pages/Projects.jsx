import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Plus, FolderOpen } from 'lucide-react'

export default function Projects() {
  const [projects] = useState([
    {
      id: 1,
      name: 'E-commerce Platform',
      description: 'Next generation e-commerce platform',
      project_key: 'ECOM',
      status: 'active'
    },
    {
      id: 2,
      name: 'Mobile App',
      description: 'Customer mobile application',
      project_key: 'MOB',
      status: 'active'
    }
  ])

  return (
    <div className="projects-page">
      <div className="page-header">
        <h1 className="page-title">Projects</h1>
        <button className="btn-primary">
          <Plus size={20} />
          New Project
        </button>
      </div>

      <div className="projects-grid">
        {projects.map(project => (
          <Link key={project.id} to={`/projects/${project.id}`} className="project-card">
            <div className="project-card-header">
              <div className="project-icon">
                <FolderOpen size={24} />
              </div>
              <span className={`status-badge ${project.status === 'active' ? 'status-active' : 'status-inactive'}`}>
                {project.status}
              </span>
            </div>
            <h3 className="project-name">{project.name}</h3>
            <p className="project-key">{project.project_key}</p>
            <p className="project-description">{project.description}</p>
            <div className="project-footer">
              <span className="created-date">
                Created recently
              </span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}