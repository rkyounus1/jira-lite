import React from 'react'
import { Link } from 'react-router-dom'
import { Target, Users, Calendar, CheckCircle } from 'lucide-react'

export default function Dashboard() {
  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1 className="page-title">Dashboard</h1>
      </div>
      
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon bg-blue-100">
            <Target className="text-blue-600" size={24} />
          </div>
          <div className="stat-content">
            <h3>Active Sprints</h3>
            <p className="stat-number">2</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon bg-green-100">
            <CheckCircle className="text-green-600" size={24} />
          </div>
          <div className="stat-content">
            <h3>Completed Stories</h3>
            <p className="stat-number">24</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon bg-orange-100">
            <Users className="text-orange-600" size={24} />
          </div>
          <div className="stat-content">
            <h3>Team Members</h3>
            <p className="stat-number">8</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon bg-purple-100">
            <Calendar className="text-purple-600" size={24} />
          </div>
          <div className="stat-content">
            <h3>Velocity</h3>
            <p className="stat-number">38</p>
          </div>
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="dashboard-section">
          <div className="section-header">
            <h2>Recent Projects</h2>
            <Link to="/projects" className="view-all">View All</Link>
          </div>
          <div className="projects-list">
            <div className="project-item">
              <h4>E-commerce Platform</h4>
              <p>ECOMP-15 stories</p>
              <span className="status-badge status-active">Active</span>
            </div>
            <div className="project-item">
              <h4>Mobile App</h4>
              <p>MOB-8 stories</p>
              <span className="status-badge status-active">Active</span>
            </div>
          </div>
        </div>

        <div className="dashboard-section">
          <div className="section-header">
            <h2>Quick Actions</h2>
          </div>
          <div className="actions-grid">
            <Link to="/projects" className="action-card">
              <FolderOpen size={24} />
              <span>Create Project</span>
            </Link>
            <div className="action-card">
              <Users size={24} />
              <span>Manage Team</span>
            </div>
            <div className="action-card">
              <BarChart3 size={24} />
              <span>View Reports</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}