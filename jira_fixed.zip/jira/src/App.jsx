import React from 'react'

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <h1>Agile Tracker is Running! 🚀</h1>
      <p>Your development server is working correctly.</p>
      <div style={{ marginTop: '2rem', padding: '1rem', background: '#f0f8ff', borderRadius: '8px' }}>
        <h3>Next Steps:</h3>
        <ul>
          <li>Add your components in the src/components folder</li>
          <li>Create pages in src/pages</li>
          <li>Add styling in src/styles</li>
        </ul>
      </div>
    </div>
  )
}

export default App